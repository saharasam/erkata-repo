import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 z-50 w-full transition-all duration-300 ${scrolled ? 'bg-black/80 backdrop-blur-md py-4' : 'bg-white/5 backdrop-blur-sm py-6'}`}>
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex flex-col">
            <Link to="/" className="text-2xl font-bold text-white tracking-wide uppercase leading-none">
              Erkata
            </Link>
            <span className="text-[10px] text-gray-300 tracking-wider font-light mt-1">
              Trusted Mediation Platform
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/login" className="text-sm font-medium text-white/90 hover:text-white transition-colors">
              Login
            </Link>
            <Link to="/become-agent" className="text-sm font-medium text-white/90 hover:text-white transition-colors">
              Become an Agent
            </Link>
            <Link 
              to="/become-operator" 
              className="px-6 py-2.5 bg-white text-black text-sm font-bold rounded-full hover:bg-gray-200 transition-all"
            >
              Become an Operator
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 text-white"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-black/95 absolute w-full h-screen top-0 left-0 z-50 flex flex-col justify-center items-center space-y-8">
           <button onClick={() => setIsOpen(false)} className="absolute top-6 right-6 text-white">
             <X className="h-8 w-8" />
           </button>
            <Link to="/" onClick={() => setIsOpen(false)} className="text-2xl font-medium text-white">Home</Link>
            <Link to="/login" onClick={() => setIsOpen(false)} className="text-2xl font-medium text-white">Login</Link>
            <Link to="/become-agent" onClick={() => setIsOpen(false)} className="text-2xl font-medium text-white">Become an Agent</Link>
            <Link to="/become-operator" onClick={() => setIsOpen(false)} className="px-8 py-3 bg-white text-black text-xl font-bold rounded-full">Become an Operator</Link>
        </div>
      )}
    </nav>
  );
};

export default Navbar;