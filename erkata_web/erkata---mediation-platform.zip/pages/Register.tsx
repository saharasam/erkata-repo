import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, User, Mail, Phone, Lock, CheckCircle2 } from 'lucide-react';

type Role = 'customer' | 'agent' | 'operator';

const Register: React.FC = () => {
  const [role, setRole] = useState<Role>('customer');

  return (
    <div className="min-h-screen flex bg-erkata-surface font-sans text-erkata-text">
      {/* Left Image Section - Matching Landing Style */}
      <div className="hidden lg:block w-1/2 relative overflow-hidden m-4 rounded-[3rem]">
        <img
          src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&auto=format&fit=crop&w=1770&q=80"
          alt="Handshake"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-erkata-primary/90 via-erkata-primary/20 to-transparent"></div>
        <div className="absolute bottom-0 left-0 p-16 text-white">
          <h2 className="text-5xl font-medium mb-6 leading-tight">Join the Network.</h2>
          <p className="text-lg text-gray-200 max-w-md font-light leading-relaxed">
            Create an account to start mediating, requesting, or fulfilling services in your zone.
          </p>
        </div>
      </div>

      {/* Right Form Section */}
      <div className="w-full lg:w-1/2 flex flex-col justify-center p-8 md:p-16 lg:p-24 overflow-y-auto">
        <div className="max-w-md mx-auto w-full">
           <Link to="/" className="inline-flex items-center text-gray-400 hover:text-erkata-primary mb-10 transition-colors font-medium text-sm tracking-wide uppercase">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Home
          </Link>

          <div className="mb-10">
            <h1 className="text-4xl md:text-5xl font-medium mb-3 text-erkata-text">Get Started</h1>
            <p className="text-gray-500 text-lg">Select your role to begin.</p>
          </div>

          {/* Luxury Role Switcher */}
          <div className="flex bg-white p-2 rounded-full border border-gray-100 mb-10 shadow-sm">
            <button
              onClick={() => setRole('customer')}
              className={`flex-1 py-3 px-4 rounded-full text-sm font-bold tracking-wide transition-all duration-300 ${role === 'customer' ? 'bg-black text-white shadow-lg' : 'text-gray-400 hover:text-gray-600'}`}
            >
              Requestor
            </button>
            <button
              onClick={() => setRole('agent')}
              className={`flex-1 py-3 px-4 rounded-full text-sm font-bold tracking-wide transition-all duration-300 ${role === 'agent' ? 'bg-erkata-secondary text-white shadow-lg' : 'text-gray-400 hover:text-gray-600'}`}
            >
              Agent
            </button>
             <button
              onClick={() => setRole('operator')}
              className={`flex-1 py-3 px-4 rounded-full text-sm font-bold tracking-wide transition-all duration-300 ${role === 'operator' ? 'bg-erkata-primary text-white shadow-lg' : 'text-gray-400 hover:text-gray-600'}`}
            >
              Operator
            </button>
          </div>

          <form className="space-y-5">
            <div className="grid grid-cols-2 gap-4">
               <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-6">First Name</label>
                <input
                  type="text"
                  placeholder="Abebe"
                  className="w-full px-8 py-4 bg-white rounded-full border border-gray-100 shadow-sm outline-none focus:ring-2 focus:ring-black/5 focus:border-black transition-all text-gray-800"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-6">Last Name</label>
                <input
                  type="text"
                  placeholder="Kebede"
                  className="w-full px-8 py-4 bg-white rounded-full border border-gray-100 shadow-sm outline-none focus:ring-2 focus:ring-black/5 focus:border-black transition-all text-gray-800"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-6">Email</label>
              <div className="relative group">
                <input
                  type="email"
                  placeholder="name@example.com"
                  className="w-full px-8 py-4 bg-white rounded-full border border-gray-100 shadow-sm outline-none focus:ring-2 focus:ring-black/5 focus:border-black transition-all pl-14 text-gray-800"
                />
                <Mail className="w-5 h-5 text-gray-400 absolute left-6 top-1/2 transform -translate-y-1/2 group-focus-within:text-black transition-colors" />
              </div>
            </div>

             <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-6">Phone</label>
              <div className="relative group">
                <input
                  type="tel"
                  placeholder="+251 911 000 000"
                  className="w-full px-8 py-4 bg-white rounded-full border border-gray-100 shadow-sm outline-none focus:ring-2 focus:ring-black/5 focus:border-black transition-all pl-14 text-gray-800"
                />
                <Phone className="w-5 h-5 text-gray-400 absolute left-6 top-1/2 transform -translate-y-1/2 group-focus-within:text-black transition-colors" />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-6">Password</label>
              <div className="relative group">
                <input
                  type="password"
                  placeholder="••••••••"
                  className="w-full px-8 py-4 bg-white rounded-full border border-gray-100 shadow-sm outline-none focus:ring-2 focus:ring-black/5 focus:border-black transition-all pl-14 text-gray-800"
                />
                <Lock className="w-5 h-5 text-gray-400 absolute left-6 top-1/2 transform -translate-y-1/2 group-focus-within:text-black transition-colors" />
              </div>
            </div>

            {/* Dynamic fields based on role */}
            {role !== 'customer' && (
              <div className="p-8 bg-white rounded-[2rem] border border-gray-100 shadow-sm mt-6">
                 <h3 className="text-sm font-bold text-erkata-text mb-4 flex items-center uppercase tracking-wider">
                    <CheckCircle2 className={`w-5 h-5 mr-2 ${role === 'agent' ? 'text-erkata-secondary' : 'text-erkata-primary'}`} />
                    {role === 'agent' ? 'Agent Details' : 'Operator Details'}
                 </h3>
                 <p className="text-sm text-gray-500 mb-6 leading-relaxed">
                   {role === 'agent' 
                     ? 'Agents must verify their identity and choose a primary zone of operation.' 
                     : 'Operators require community verification and must reside in the Woreda they serve.'}
                 </p>
                 <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-4">Primary Zone</label>
                    <div className="relative">
                      <select className="w-full px-8 py-4 bg-gray-50 rounded-full border-none outline-none focus:ring-2 focus:ring-black/5 focus:bg-white transition-all text-gray-800 appearance-none cursor-pointer">
                        <option>Select Zone...</option>
                        <option>Bole</option>
                        <option>Yeka</option>
                        <option>Kirkos</option>
                        <option>Arada</option>
                        <option>Lideta</option>
                      </select>
                      <div className="absolute right-6 top-1/2 transform -translate-y-1/2 pointer-events-none">
                        <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                      </div>
                    </div>
                 </div>
              </div>
            )}

            <button type="button" className={`w-full text-white font-medium text-lg py-5 rounded-full shadow-xl hover:shadow-2xl hover:scale-[1.01] active:scale-[0.99] transition-all duration-300 mt-6 ${role === 'agent' ? 'bg-erkata-secondary' : role === 'operator' ? 'bg-erkata-primary' : 'bg-black'}`}>
              {role === 'customer' ? 'Create Account' : 'Submit Application'}
            </button>
          </form>

          <div className="mt-10 text-center">
            <p className="text-gray-500">Already have an account?</p>
            <Link to="/login" className="inline-block mt-2 text-erkata-text font-bold border-b-2 border-erkata-primary hover:text-erkata-primary transition-colors pb-1">
              Sign In
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;