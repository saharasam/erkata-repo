import React from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowRight, 
  ShieldCheck,
  UserCheck,
  FileText,
  MapPin,
  CheckCircle2,
  Lock
} from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const Landing: React.FC = () => {
  return (
    <div className="bg-erkata-surface font-sans text-erkata-text">
      <Navbar />

      {/* 1. Hero Section */}
      <section className="relative w-full min-h-[90vh] rounded-b-[3rem] overflow-hidden mx-auto flex items-end">
        <div className="absolute inset-0 bg-gradient-to-b from-erkata-primary to-[#05232d]">
           {/* Abstract pattern or subtle image overlay could go here */}
           <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
        </div>

        {/* Content Positioned Bottom Left */}
        <div className="relative z-10 w-full p-6 md:p-12 lg:p-24 pb-20">
          <div className="max-w-[1440px] mx-auto">
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-medium text-white tracking-tight leading-[1.1] mb-8 max-w-5xl">
              Get it done. <br />
              <span className="text-erkata-accent">Fairly.</span> <br />
              Through trusted local mediation.
            </h1>
            
            <p className="text-gray-200 text-lg md:text-xl max-w-3xl mb-12 leading-relaxed border-l-4 border-erkata-accent pl-6">
              No public listings. No direct contact. No shortcuts. <br />
              Ethiopia’s structured platform where every request goes through a neutral operator before reaching a verified local agent.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                to="/register" 
                className="inline-flex items-center justify-center bg-erkata-accent hover:bg-erkata-secondary text-black text-lg font-bold px-10 py-5 rounded-full transition-all hover:scale-105"
              >
                Submit Your Request
              </Link>
              <Link 
                to="/become-agent" 
                className="inline-flex items-center justify-center border-2 border-erkata-accent text-erkata-accent hover:bg-erkata-accent/10 text-lg font-bold px-10 py-5 rounded-full transition-all"
              >
                Join as Agent
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 2. How It Works */}
      <section className="py-24 px-6 md:px-12 lg:px-20 max-w-[1440px] mx-auto bg-white/50 rounded-[3rem] my-12 mx-4 md:mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-medium text-erkata-text mb-4">How Erkata Actually Works</h2>
          <div className="w-24 h-1 bg-erkata-primary mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Step 1 */}
          <div className="bg-white p-10 rounded-[2rem] shadow-sm border border-gray-100 relative overflow-hidden group hover:shadow-xl transition-all duration-300">
            <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
              <FileText className="w-32 h-32" />
            </div>
            <div className="w-12 h-12 bg-erkata-primary text-white rounded-full flex items-center justify-center font-bold text-xl mb-6">1</div>
            <h3 className="text-2xl font-bold mb-4">Submit Your Need</h3>
            <p className="text-gray-600 leading-relaxed">
              You fill a structured form describing exactly what you want (property, furniture, service…). 
              Your request goes <strong>only to an operator</strong> in your area — never public.
            </p>
          </div>

          {/* Step 2 */}
          <div className="bg-white p-10 rounded-[2rem] shadow-sm border border-gray-100 relative overflow-hidden group hover:shadow-xl transition-all duration-300">
             <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
              <UserCheck className="w-32 h-32" />
            </div>
            <div className="w-12 h-12 bg-erkata-primary text-white rounded-full flex items-center justify-center font-bold text-xl mb-6">2</div>
            <h3 className="text-2xl font-bold mb-4">Neutral Mediation & Matching</h3>
            <p className="text-gray-600 leading-relaxed">
              A certified local operator reviews your request, validates it and assigns it to the most suitable subscribed agent according to:
            </p>
            <ul className="mt-4 space-y-2 text-sm text-gray-500 font-medium">
              <li className="flex items-center"><CheckCircle2 className="w-4 h-4 mr-2 text-erkata-secondary"/> Geographic zone</li>
              <li className="flex items-center"><CheckCircle2 className="w-4 h-4 mr-2 text-erkata-secondary"/> Agent tier & specialization</li>
              <li className="flex items-center"><CheckCircle2 className="w-4 h-4 mr-2 text-erkata-secondary"/> Current availability</li>
            </ul>
          </div>

          {/* Step 3 */}
          <div className="bg-white p-10 rounded-[2rem] shadow-sm border border-gray-100 relative overflow-hidden group hover:shadow-xl transition-all duration-300">
             <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
              <ShieldCheck className="w-32 h-32" />
            </div>
            <div className="w-12 h-12 bg-erkata-primary text-white rounded-full flex items-center justify-center font-bold text-xl mb-6">3</div>
            <h3 className="text-2xl font-bold mb-4">Delivery + Protected Feedback</h3>
            <p className="text-gray-600 leading-relaxed">
              The agent delivers the service or transaction. Both sides submit feedback through the operator.
              Only bundled, anonymized feedback reaches higher levels — final resolution always requires Super Admin approval.
            </p>
          </div>
        </div>
      </section>

      {/* 3. Who Is This For? */}
      <section className="py-12 px-6 md:px-12 lg:px-20 max-w-[1440px] mx-auto">
        <h2 className="text-3xl md:text-4xl font-medium mb-12">Who Is This For?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Requestors */}
          <div className="bg-erkata-primary text-white p-10 rounded-[2.5rem] flex flex-col justify-between min-h-[320px]">
            <div>
              <h3 className="text-2xl font-bold mb-4">Requestors <br/><span className="text-white/60 text-lg font-normal">(Buyers / Sellers)</span></h3>
              <p className="text-gray-200 leading-relaxed">
                You want transparency, zone-respecting service and protection against unverified intermediaries.
              </p>
            </div>
            <Link to="/register" className="mt-8 inline-flex items-center text-erkata-accent font-bold hover:text-white transition-colors">
              Submit a Request <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </div>

          {/* Agents */}
          <div className="bg-white border border-gray-200 p-10 rounded-[2.5rem] flex flex-col justify-between min-h-[320px]">
             <div>
              <h3 className="text-2xl font-bold mb-4 text-erkata-text">Agents <br/><span className="text-gray-500 text-lg font-normal">(Executors)</span></h3>
              <p className="text-gray-600 leading-relaxed">
                You want qualified, pre-validated leads in your operating zones without competing in a public free-for-all marketplace.
                Higher tiers = more referral income + larger geographic rights.
              </p>
            </div>
            <Link to="/become-agent" className="mt-8 inline-flex items-center text-erkata-secondary font-bold hover:text-black transition-colors">
              Become an Agent <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </div>

          {/* Operators */}
          <div className="bg-white border border-gray-200 p-10 rounded-[2.5rem] flex flex-col justify-between min-h-[320px]">
             <div>
              <h3 className="text-2xl font-bold mb-4 text-erkata-text">Operators <br/><span className="text-gray-500 text-lg font-normal">(Neutral Mediators)</span></h3>
              <p className="text-gray-600 leading-relaxed">
                You want to play a respected, paid mediation role in your community while enforcing structure and fairness.
              </p>
            </div>
            <Link to="/become-operator" className="mt-8 inline-flex items-center text-erkata-secondary font-bold hover:text-black transition-colors">
              Apply as Operator <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* 4. Agent Progression Tiers Table */}
      <section className="py-24 px-6 md:px-12 lg:px-20 max-w-[1440px] mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-medium text-erkata-text mb-4">Choose Your Path as Agent</h2>
          <p className="text-gray-500 max-w-2xl mx-auto">
            Referral commission applies only to first-generation (direct) referrals. Higher tiers unlock significantly more earning potential through referrals and wider zone rights.
          </p>
        </div>

        <div className="overflow-x-auto rounded-[2rem] border border-gray-200 shadow-xl">
          <table className="w-full text-left bg-white border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="p-6 font-bold text-gray-900 uppercase text-sm tracking-wider">Package</th>
                <th className="p-6 font-bold text-gray-500 uppercase text-xs tracking-wider">Referral Slots</th>
                <th className="p-6 font-bold text-gray-500 uppercase text-xs tracking-wider">Free Zones</th>
                <th className="p-6 font-bold text-gray-500 uppercase text-xs tracking-wider">Geographic Access</th>
                <th className="p-6 font-bold text-gray-500 uppercase text-xs tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              <tr className="hover:bg-gray-50/50 transition-colors">
                <td className="p-6 font-bold text-gray-900">Free</td>
                <td className="p-6 text-gray-600">3</td>
                <td className="p-6 text-gray-600">1</td>
                <td className="p-6 text-gray-600">Very limited</td>
                <td className="p-6"><span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-bold uppercase">Basic</span></td>
              </tr>
              <tr className="hover:bg-gray-50/50 transition-colors">
                <td className="p-6 font-bold text-gray-900">Peace</td>
                <td className="p-6 text-gray-600">7</td>
                <td className="p-6 text-gray-600">2</td>
                <td className="p-6 text-gray-600">Small expansion</td>
                <td className="p-6"><span className="px-3 py-1 bg-erkata-accent/20 text-erkata-primary rounded-full text-xs font-bold uppercase">Paid</span></td>
              </tr>
              <tr className="hover:bg-gray-50/50 transition-colors">
                <td className="p-6 font-bold text-gray-900">Love</td>
                <td className="p-6 text-gray-600">16</td>
                <td className="p-6 text-gray-600">3</td>
                <td className="p-6 text-gray-600">Medium coverage</td>
                <td className="p-6"><span className="px-3 py-1 bg-erkata-accent/20 text-erkata-primary rounded-full text-xs font-bold uppercase">Paid</span></td>
              </tr>
              <tr className="hover:bg-gray-50/50 transition-colors">
                <td className="p-6 font-bold text-gray-900">Unity</td>
                <td className="p-6 text-gray-600">23</td>
                <td className="p-6 text-gray-600">5</td>
                <td className="p-6 text-gray-600">Large coverage</td>
                <td className="p-6"><span className="px-3 py-1 bg-erkata-accent/20 text-erkata-primary rounded-full text-xs font-bold uppercase">Paid</span></td>
              </tr>
              <tr className="bg-erkata-accent/10 border-l-4 border-l-erkata-secondary">
                <td className="p-6 font-bold text-erkata-primary text-lg">Abundant Life</td>
                <td className="p-6 font-bold text-erkata-primary">31</td>
                <td className="p-6 font-bold text-erkata-primary">Unlimited</td>
                <td className="p-6 font-bold text-erkata-primary">Full map-based access</td>
                <td className="p-6"><span className="px-3 py-1 bg-erkata-secondary text-white rounded-full text-xs font-bold uppercase shadow-sm">Premium</span></td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <div className="mt-12 text-center">
          <Link to="/become-agent" className="text-lg font-bold text-erkata-secondary hover:text-black underline underline-offset-4 transition-colors">
            Start as Free Agent – Upgrade Anytime
          </Link>
        </div>
      </section>

      {/* 5. Geographic Zoning */}
      <section className="py-20 px-6 md:px-12 lg:px-20 max-w-[1440px] mx-auto bg-white rounded-[3rem] shadow-sm border border-gray-100 flex flex-col lg:flex-row items-center gap-16">
        <div className="lg:w-1/2">
           <div className="inline-block px-4 py-2 bg-gray-100 rounded-full text-xs font-bold uppercase tracking-widest text-gray-500 mb-6">
             Structure
           </div>
           <h2 className="text-4xl md:text-5xl font-medium mb-6">Local. Zoned. Accountable.</h2>
           <div className="space-y-6 text-lg text-gray-600 leading-relaxed">
             <p>
               Agents can only accept and fulfill requests inside zones they have rights to.
             </p>
             <p>
               Zones follow Ethiopia’s administrative divisions (kifle ketema / woreda).
               Higher-tier agents progressively unlock larger territories.
             </p>
             <p className="font-medium text-erkata-secondary">
               This structure protects both requestors and agents from unqualified long-distance matching.
             </p>
           </div>
        </div>
        <div className="lg:w-1/2 w-full h-[400px] bg-gray-100 rounded-[2rem] relative overflow-hidden flex items-center justify-center">
            {/* Abstract Map Visual */}
            <div className="absolute inset-0 opacity-10 bg-[url('https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Ethiopia_adm_location_map.svg/1024px-Ethiopia_adm_location_map.svg.png')] bg-cover bg-center"></div>
            <div className="relative z-10 p-8 text-center">
               <MapPin className="w-16 h-16 text-erkata-secondary mx-auto mb-4" />
               <p className="text-gray-500 font-medium">Zone Rights Visualization</p>
               <div className="mt-4 flex justify-center gap-2">
                 <span className="w-3 h-3 rounded-full bg-gray-300"></span>
                 <span className="w-3 h-3 rounded-full bg-gray-300"></span>
                 <span className="w-3 h-3 rounded-full bg-erkata-accent animate-pulse"></span>
               </div>
            </div>
        </div>
      </section>

      {/* 6. Final Trust Section */}
      <section className="py-24 px-6 md:px-12 lg:px-20 text-center">
        <h2 className="text-4xl md:text-6xl font-medium mb-8 leading-tight">
          Trust is not promised. <br/>
          <span className="text-gray-400">It is enforced.</span>
        </h2>
        
        <div className="flex flex-col md:flex-row justify-center gap-4 md:gap-12 mb-16 text-left md:text-center max-w-4xl mx-auto">
           <div className="flex items-center md:flex-col gap-4">
             <div className="w-2 h-2 bg-erkata-accent rounded-full md:hidden"></div>
             <p className="text-lg text-gray-600">Every transaction has a neutral operator in the middle</p>
           </div>
           <div className="flex items-center md:flex-col gap-4">
             <div className="w-2 h-2 bg-erkata-accent rounded-full md:hidden"></div>
             <p className="text-lg text-gray-600">No hidden direct contact before validation</p>
           </div>
           <div className="flex items-center md:flex-col gap-4">
             <div className="w-2 h-2 bg-erkata-accent rounded-full md:hidden"></div>
             <p className="text-lg text-gray-600">Immutable feedback escalation chain ending at Super Admin</p>
           </div>
        </div>

        <Link 
          to="/register" 
          className="inline-flex items-center justify-center bg-erkata-accent hover:bg-erkata-secondary text-black text-xl font-bold px-12 py-6 rounded-full transition-all shadow-lg hover:shadow-xl hover:-translate-y-1"
        >
          Begin Your Journey with Erkata
        </Link>
      </section>

      <Footer />
    </div>
  );
};

export default Landing;