import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Mail, Lock } from 'lucide-react';

const Login: React.FC = () => {
  return (
    <div className="min-h-screen flex bg-erkata-surface font-sans text-erkata-text">
      {/* Left Image Section - Matching Landing Hero Style */}
      <div className="hidden lg:block w-1/2 relative overflow-hidden m-4 rounded-[3rem]">
        <img
          src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1769&q=80"
          alt="Office"
          className="absolute inset-0 w-full h-full object-cover"
        />
        {/* Consistent Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent"></div>
        
        <div className="absolute bottom-0 left-0 p-16 text-white">
          <h2 className="text-5xl font-medium mb-6 leading-tight">Welcome Back.</h2>
          <p className="text-lg text-gray-200 max-w-md font-light leading-relaxed">
            Access your dashboard to manage requests, zones, and mediation tasks securely.
          </p>
        </div>
      </div>

      {/* Right Form Section */}
      <div className="w-full lg:w-1/2 flex flex-col justify-center p-8 md:p-16 lg:p-24">
        <div className="max-w-md mx-auto w-full">
          <Link to="/" className="inline-flex items-center text-gray-400 hover:text-erkata-primary mb-12 transition-colors font-medium text-sm tracking-wide uppercase">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Home
          </Link>

          <div className="mb-12">
            <h1 className="text-4xl md:text-5xl font-medium mb-3 text-erkata-text">Sign In</h1>
            <p className="text-gray-500 text-lg">Enter your details to proceed.</p>
          </div>

          <form className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-gray-500 ml-6">Email Address</label>
              <div className="relative group">
                <input
                  type="email"
                  placeholder="name@example.com"
                  className="w-full px-8 py-5 bg-white rounded-full border border-gray-100 shadow-sm outline-none focus:ring-2 focus:ring-black/5 focus:border-black transition-all pl-14 text-gray-800 placeholder-gray-400"
                />
                <Mail className="w-5 h-5 text-gray-400 absolute left-6 top-1/2 transform -translate-y-1/2 group-focus-within:text-erkata-primary transition-colors" />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center ml-6 mr-2">
                <label className="text-xs font-bold uppercase tracking-widest text-gray-500">Password</label>
                <Link to="#" className="text-xs font-bold text-erkata-primary hover:text-black transition-colors uppercase tracking-wider">Forgot?</Link>
              </div>
              <div className="relative group">
                <input
                  type="password"
                  placeholder="••••••••"
                  className="w-full px-8 py-5 bg-white rounded-full border border-gray-100 shadow-sm outline-none focus:ring-2 focus:ring-black/5 focus:border-black transition-all pl-14 text-gray-800 placeholder-gray-400"
                />
                <Lock className="w-5 h-5 text-gray-400 absolute left-6 top-1/2 transform -translate-y-1/2 group-focus-within:text-erkata-primary transition-colors" />
              </div>
            </div>

            <button type="button" className="w-full bg-erkata-primary text-white font-medium text-lg py-5 rounded-full shadow-xl shadow-erkata-primary/20 hover:bg-black hover:shadow-2xl hover:scale-[1.01] active:scale-[0.99] transition-all duration-300 mt-4">
              Access Account
            </button>
          </form>

          <div className="mt-12 text-center">
            <p className="text-gray-500">Don't have an account?</p>
            <Link to="/register" className="inline-block mt-2 text-erkata-text font-bold border-b-2 border-erkata-accent hover:text-erkata-accent transition-colors pb-1">
              Create an account
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;