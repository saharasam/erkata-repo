import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Register from './pages/Register';

const App: React.FC = () => {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        {/* Reuse Register/Landing pages for now, but in a real app these might be specific landing pages or pre-filled register pages */}
        <Route path="/become-agent" element={<Landing />} /> 
        <Route path="/become-operator" element={<Landing />} />
      </Routes>
    </HashRouter>
  );
};

export default App;